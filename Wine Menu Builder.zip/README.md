
  # Wine Menu Builder

  This is a code bundle for Wine Menu Builder. The original project is available at https://www.figma.com/design/19qEEWeyv3ijEjmnJomOiA/Wine-Menu-Builder.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  