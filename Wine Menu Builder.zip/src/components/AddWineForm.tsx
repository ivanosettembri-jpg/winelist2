import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import type { Wine } from '../App';

interface AddWineFormProps {
  onAddWine: (wine: Omit<Wine, 'id'>) => void;
  onCancel: () => void;
}

export function AddWineForm({ onAddWine, onCancel }: AddWineFormProps) {
  const [formData, setFormData] = useState({
    nome: '',
    produttore: '',
    uvaggio: '',
    luogo: '',
    regione: '',
    anno: '',
    prezzo: '',
    tipologia: '',
    nazionalita: '',
  });

  const tipologie = [
    'Vini Bianchi',
    'Vini Rossi',
    'Vini Rosati',
    'Bollicine',
    'Vini Dolci',
    'Vini Fortificati',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (Object.values(formData).every(value => value.trim() !== '')) {
      onAddWine(formData);
      setFormData({
        nome: '',
        produttore: '',
        uvaggio: '',
        luogo: '',
        regione: '',
        anno: '',
        prezzo: '',
        tipologia: '',
        nazionalita: '',
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Aggiungi Nuovo Vino</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tipologia">Tipologia *</Label>
              <Select
                value={formData.tipologia}
                onValueChange={(value) => setFormData({ ...formData, tipologia: value })}
              >
                <SelectTrigger id="tipologia">
                  <SelectValue placeholder="Seleziona tipologia" />
                </SelectTrigger>
                <SelectContent>
                  {tipologie.map((tip) => (
                    <SelectItem key={tip} value={tip}>
                      {tip}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="nazionalita">Nazionalità *</Label>
              <Input
                id="nazionalita"
                value={formData.nazionalita}
                onChange={(e) => setFormData({ ...formData, nazionalita: e.target.value })}
                placeholder="es. Italia, Francia"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="regione">Regione *</Label>
              <Input
                id="regione"
                value={formData.regione}
                onChange={(e) => setFormData({ ...formData, regione: e.target.value })}
                placeholder="es. Toscana, Bordeaux"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome">Nome Vino *</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="es. Brunello di Montalcino"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="produttore">Produttore *</Label>
              <Input
                id="produttore"
                value={formData.produttore}
                onChange={(e) => setFormData({ ...formData, produttore: e.target.value })}
                placeholder="es. Biondi Santi"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="uvaggio">Uvaggio *</Label>
              <Input
                id="uvaggio"
                value={formData.uvaggio}
                onChange={(e) => setFormData({ ...formData, uvaggio: e.target.value })}
                placeholder="es. Sangiovese 100%"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="luogo">Luogo *</Label>
              <Input
                id="luogo"
                value={formData.luogo}
                onChange={(e) => setFormData({ ...formData, luogo: e.target.value })}
                placeholder="es. Montalcino"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="anno">Anno *</Label>
              <Input
                id="anno"
                value={formData.anno}
                onChange={(e) => setFormData({ ...formData, anno: e.target.value })}
                placeholder="es. 2018"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="prezzo">Prezzo (€) *</Label>
            <Input
              id="prezzo"
              type="number"
              step="0.01"
              value={formData.prezzo}
              onChange={(e) => setFormData({ ...formData, prezzo: e.target.value })}
              placeholder="es. 45.00"
              required
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annulla
            </Button>
            <Button type="submit">Aggiungi Vino</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
