import { Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import type { Wine } from '../App';

interface WineMenuProps {
  wines: Wine[];
  onDeleteWine: (id: string) => void;
}

export function WineMenu({ wines, onDeleteWine }: WineMenuProps) {
  // Organizza i vini per tipologia -> nazionalità -> regione
  const organizedWines: Record<string, Record<string, Record<string, Wine[]>>> = {};
  
  wines.forEach(wine => {
    if (!organizedWines[wine.tipologia]) {
      organizedWines[wine.tipologia] = {};
    }
    if (!organizedWines[wine.tipologia][wine.nazionalita]) {
      organizedWines[wine.tipologia][wine.nazionalita] = {};
    }
    if (!organizedWines[wine.tipologia][wine.nazionalita][wine.regione]) {
      organizedWines[wine.tipologia][wine.nazionalita][wine.regione] = [];
    }
    organizedWines[wine.tipologia][wine.nazionalita][wine.regione].push(wine);
  });

  return (
    <div className="space-y-12">
      {Object.entries(organizedWines).map(([tipologia, nazionalitaObj]) => (
        <div key={tipologia} className="space-y-6">
          {/* Titolo Tipologia */}
          <div className="border-b-2 border-neutral-900 pb-2">
            <h2 className="text-neutral-900">{tipologia}</h2>
          </div>

          {Object.entries(nazionalitaObj).map(([nazionalita, regioniObj]) => (
            <div key={nazionalita} className="space-y-4">
              {/* Titolo Nazionalità */}
              <div className="border-b border-neutral-300 pb-1">
                <h3 className="text-neutral-700">{nazionalita}</h3>
              </div>

              {Object.entries(regioniObj).map(([regione, winesList]) => (
                <div key={regione} className="space-y-2">
                  {/* Titolo Regione */}
                  <div className="pl-2">
                    <h4 className="text-neutral-600">{regione}</h4>
                  </div>

                  {/* Griglia Vini */}
                  <div className="overflow-x-auto">
                    <div className="min-w-full">
                      {/* Header della griglia */}
                      <div className="grid grid-cols-[2fr_1.5fr_2fr_1.5fr_0.8fr_1fr_80px] gap-3 bg-neutral-100 px-4 py-3 rounded-t-lg border-b border-neutral-200">
                        <div className="text-neutral-700">Nome</div>
                        <div className="text-neutral-700">Produttore</div>
                        <div className="text-neutral-700">Uvaggio</div>
                        <div className="text-neutral-700">Luogo</div>
                        <div className="text-neutral-700">Anno</div>
                        <div className="text-neutral-700 text-right">Prezzo</div>
                        <div></div>
                      </div>

                      {/* Righe dei vini */}
                      {winesList.map((wine, index) => (
                        <div
                          key={wine.id}
                          className={`grid grid-cols-[2fr_1.5fr_2fr_1.5fr_0.8fr_1fr_80px] gap-3 px-4 py-3 border-b border-neutral-200 hover:bg-neutral-50 transition-colors group ${
                            index === winesList.length - 1 ? 'rounded-b-lg' : ''
                          }`}
                        >
                          <div className="text-neutral-900">{wine.nome}</div>
                          <div className="text-neutral-700">{wine.produttore}</div>
                          <div className="text-neutral-600">{wine.uvaggio}</div>
                          <div className="text-neutral-600">{wine.luogo}</div>
                          <div className="text-neutral-600">{wine.anno}</div>
                          <div className="text-neutral-900 text-right">€ {wine.prezzo}</div>
                          <div className="flex justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDeleteWine(wine.id)}
                              className="opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
