import { useState } from 'react';
import { AddWineForm } from './components/AddWineForm';
import { WineMenu } from './components/WineMenu';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { FileDown, Plus, Download, Upload } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface Wine {
  id: string;
  nome: string;
  produttore: string;
  uvaggio: string;
  luogo: string;
  regione: string;
  anno: string;
  prezzo: string;
  tipologia: string;
  nazionalita: string;
}

function App() {
  const [wines, setWines] = useState<Wine[]>([]);
  const [showForm, setShowForm] = useState(false);

  const handleAddWine = (wine: Omit<Wine, 'id'>) => {
    const newWine: Wine = {
      ...wine,
      id: Date.now().toString(),
    };
    setWines([...wines, newWine]);
    setShowForm(false);
  };

  const handleDeleteWine = (id: string) => {
    setWines(wines.filter(wine => wine.id !== id));
  };

  const exportToJSON = () => {
    const dataStr = JSON.stringify(wines, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `carta-vini-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importFromJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedWines = JSON.parse(e.target?.result as string);
          if (Array.isArray(importedWines)) {
            setWines(importedWines);
          } else {
            alert('Formato file non valido');
          }
        } catch (error) {
          alert('Errore nella lettura del file');
        }
      };
      reader.readAsText(file);
    }
    // Reset input per permettere di reimportare lo stesso file
    event.target.value = '';
  };

  const exportToPDF = () => {
    const doc = new jsPDF('portrait');
    
    // Titolo principale con decorazione
    doc.setFontSize(26);
    doc.setTextColor(40, 40, 40);
    doc.text('Carta dei Vini', 105, 25, { align: 'center' });
    
    // Linea decorativa sotto il titolo
    doc.setDrawColor(180, 180, 180);
    doc.setLineWidth(0.5);
    doc.line(40, 30, 170, 30);
    
    let yPosition = 45;

    // Organizza i vini per tipologia -> nazionalità -> regione
    const organizedWines: Record<string, Record<string, Record<string, Wine[]>>> = {};
    
    wines.forEach(wine => {
      if (!organizedWines[wine.tipologia]) {
        organizedWines[wine.tipologia] = {};
      }
      if (!organizedWines[wine.tipologia][wine.nazionalita]) {
        organizedWines[wine.tipologia][wine.nazionalita] = {};
      }
      if (!organizedWines[wine.tipologia][wine.nazionalita][wine.regione]) {
        organizedWines[wine.tipologia][wine.nazionalita][wine.regione] = [];
      }
      organizedWines[wine.tipologia][wine.nazionalita][wine.regione].push(wine);
    });

    // Per ogni tipologia
    Object.entries(organizedWines).forEach(([tipologia, nazionalitaObj], tipIndex) => {
      if (tipIndex > 0 && yPosition < 60) {
        doc.addPage('portrait');
        yPosition = 25;
      }

      // Verifica spazio per il titolo
      if (yPosition > 250) {
        doc.addPage('portrait');
        yPosition = 25;
      }

      // Titolo Tipologia con background
      doc.setFillColor(245, 245, 245);
      doc.rect(15, yPosition - 5, 180, 10, 'F');
      doc.setFontSize(14);
      doc.setTextColor(50, 50, 50);
      doc.text(tipologia.toUpperCase(), 20, yPosition + 2);
      yPosition += 12;

      // Per ogni nazionalità
      Object.entries(nazionalitaObj).forEach(([nazionalita, regioniObj]) => {
        // Verifica spazio
        if (yPosition > 250) {
          doc.addPage('portrait');
          yPosition = 25;
        }

        // Titolo Nazionalità
        doc.setFontSize(11);
        doc.setTextColor(80, 80, 80);
        doc.text(nazionalita, 20, yPosition);
        yPosition += 7;

        // Per ogni regione
        Object.entries(regioniObj).forEach(([regione, winesList]) => {
          // Verifica spazio
          if (yPosition > 245) {
            doc.addPage('portrait');
            yPosition = 25;
          }

          // Titolo Regione
          doc.setFontSize(9);
          doc.setTextColor(110, 110, 110);
          doc.text(regione, 25, yPosition);
          yPosition += 5;

          // Tabella vini
          const tableData = winesList.map(wine => [
            wine.nome,
            wine.produttore,
            wine.uvaggio,
            wine.anno,
            `€ ${wine.prezzo}`,
          ]);

          autoTable(doc, {
            startY: yPosition,
            head: [['Nome', 'Produttore', 'Uvaggio', 'Anno', 'Prezzo']],
            body: tableData,
            theme: 'plain',
            styles: {
              fontSize: 9,
              cellPadding: 3,
              lineColor: [220, 220, 220],
              lineWidth: 0.1,
            },
            headStyles: {
              fillColor: [250, 250, 250],
              textColor: [70, 70, 70],
              fontStyle: 'bold',
              lineWidth: 0.3,
              lineColor: [180, 180, 180],
            },
            bodyStyles: {
              textColor: [60, 60, 60],
            },
            columnStyles: {
              0: { cellWidth: 50, fontStyle: 'bold', textColor: [40, 40, 40] },
              1: { cellWidth: 40 },
              2: { cellWidth: 45 },
              3: { cellWidth: 16, halign: 'center' },
              4: { cellWidth: 19, halign: 'right', fontStyle: 'bold', textColor: [40, 40, 40] },
            },
            margin: { left: 20, right: 20 },
            alternateRowStyles: {
              fillColor: [252, 252, 252],
            },
          });

          yPosition = (doc as any).lastAutoTable.finalY + 8;

          // Se siamo vicini al fondo della pagina, crea una nuova pagina
          if (yPosition > 250) {
            doc.addPage('portrait');
            yPosition = 25;
          }
        });

        // Spazio extra dopo ogni nazionalità
        yPosition += 3;
      });

      // Spazio extra dopo ogni tipologia
      yPosition += 5;
    });

    // Footer su ogni pagina
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(`Pagina ${i} di ${pageCount}`, 105, 285, { align: 'center' });
      
      // Linea decorativa nel footer
      doc.setDrawColor(220, 220, 220);
      doc.setLineWidth(0.3);
      doc.line(20, 280, 190, 280);
    }

    doc.save('carta-dei-vini.pdf');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="mx-auto max-w-7xl p-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-neutral-900">Carta dei Vini</h1>
            <p className="text-neutral-600 mt-2">Gestisci e organizza la tua selezione di vini</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowForm(!showForm)}
              variant={showForm ? "outline" : "default"}
            >
              <Plus className="mr-2 h-4 w-4" />
              {showForm ? 'Chiudi Form' : 'Aggiungi Vino'}
            </Button>
            {wines.length > 0 && (
              <>
                <Button onClick={exportToJSON} variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Esporta Dati
                </Button>
                <Button onClick={exportToPDF} variant="outline">
                  <FileDown className="mr-2 h-4 w-4" />
                  Esporta PDF
                </Button>
              </>
            )}
            <Button variant="outline" asChild>
              <label htmlFor="import-file" className="cursor-pointer">
                <Upload className="mr-2 h-4 w-4" />
                Importa Dati
              </label>
            </Button>
            <input
              id="import-file"
              type="file"
              accept=".json"
              onChange={importFromJSON}
              className="hidden"
            />
          </div>
        </div>

        {showForm && (
          <div className="mb-8">
            <AddWineForm onAddWine={handleAddWine} onCancel={() => setShowForm(false)} />
          </div>
        )}

        {wines.length === 0 ? (
          <div className="rounded-lg border-2 border-dashed border-neutral-300 p-12 text-center">
            <p className="text-neutral-500">
              Nessun vino aggiunto. Inizia ad aggiungere vini alla tua carta o importa un file esistente.
            </p>
          </div>
        ) : (
          <WineMenu wines={wines} onDeleteWine={handleDeleteWine} />
        )}
      </div>
    </div>
  );
}

export default App;